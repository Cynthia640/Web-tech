<?php 
session_start();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration Form</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1 class=header>X COMPANY </h1>
	<form action="db.php" method="post">
		<div class="input-group">
		Name: <input type="text" name="name">
		</div>
		<br>
		<br>
		<div class="input-group">
		Email: <input type="text" name="email">
			</div>
		<br>
		<br>
		
		Gender: 
		        <input type="radio" name="gender" value="male"> Male
				<input type="radio" name="gender" value="female"> Female
				<input type="radio" name="gender" value="other"> Other
				<br>
				<br>
							

		<div class="input-group">
		Password: <input type="text" name="password">
		<br>
		<br>
        </div>
		<input type="submit" name="submit" value="SUBMIT">
		<br>
		
	</form>

</body>
</html>


<?php 
  if (isset($_POST['submit']))
  {
	
	  $_SESSION['Name']=$_POST['name'];
	    $_SESSION['Email']=$_POST['email'];
		  $_SESSION['Gender']=$_POST['gender'];
	  $_SESSION['Password']=$_POST['password'];
	  
	  
	  
  }

?>